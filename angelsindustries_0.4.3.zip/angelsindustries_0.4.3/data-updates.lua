local OV = angelsmods.functions.OV

require("prototypes.buildings.nuclear-reactor-updates")
require("prototypes.angels-industries-override")

OV.execute()
