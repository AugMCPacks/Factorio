if mods["bobplates"] then
  data.raw["bool-setting"]["angels-enable-industries"].default_value = true
end
