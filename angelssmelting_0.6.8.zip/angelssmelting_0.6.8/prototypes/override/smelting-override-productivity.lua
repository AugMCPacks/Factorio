angelsmods.functions.allow_productivity("angels-plate-steel")
angelsmods.functions.allow_productivity("angels-roll-steel-converting")
angelsmods.functions.allow_productivity("angels-solder")
angelsmods.functions.allow_productivity("angels-roll-solder-converting")

angelsmods.functions.allow_productivity("angels-plate-aluminium")
angelsmods.functions.allow_productivity("angels-roll-aluminium-converting")

angelsmods.functions.allow_productivity("angels-plate-chrome")
angelsmods.functions.allow_productivity("angels-roll-chrome-converting")

angelsmods.functions.allow_productivity("angels-plate-cobalt")
angelsmods.functions.allow_productivity("angels-roll-cobalt-converting")

angelsmods.functions.allow_productivity("angels-plate-copper")
angelsmods.functions.allow_productivity("angels-wire-coil-copper-converting")
angelsmods.functions.allow_productivity("angels-roll-copper-converting")

angelsmods.functions.allow_productivity("angels-plate-gold")
angelsmods.functions.allow_productivity("angels-wire-coil-gold-converting")
angelsmods.functions.allow_productivity("angels-roll-gold-converting")

angelsmods.functions.allow_productivity("angels-plate-iron")
angelsmods.functions.allow_productivity("angels-roll-iron-converting")

angelsmods.functions.allow_productivity("angels-plate-lead")
angelsmods.functions.allow_productivity("angels-roll-lead-converting")

angelsmods.functions.allow_productivity("angels-plate-manganese")
angelsmods.functions.allow_productivity("angels-roll-manganese-converting")

angelsmods.functions.allow_productivity("angels-plate-nickel")
angelsmods.functions.allow_productivity("angels-roll-nickel-converting")

angelsmods.functions.allow_productivity("angels-plate-platinum")
angelsmods.functions.allow_productivity("angels-wire-coil-platinum-converting")
angelsmods.functions.allow_productivity("angels-roll-platinum-converting")

angelsmods.functions.allow_productivity("angels-mono-silicon-1")
angelsmods.functions.allow_productivity("angels-mono-silicon-2")

angelsmods.functions.allow_productivity("angels-plate-silver")
angelsmods.functions.allow_productivity("angels-wire-coil-silver-converting")
angelsmods.functions.allow_productivity("angels-roll-silver-converting")

angelsmods.functions.allow_productivity("angels-plate-tin")
angelsmods.functions.allow_productivity("angels-wire-coil-tin-converting")
angelsmods.functions.allow_productivity("angels-roll-tin-converting")

angelsmods.functions.allow_productivity("angels-plate-titanium")
angelsmods.functions.allow_productivity("angels-roll-titanium-converting")

angelsmods.functions.allow_productivity("angels-plate-tungsten")

angelsmods.functions.allow_productivity("angels-plate-zinc")
angelsmods.functions.allow_productivity("angels-roll-zinc-converting")

angelsmods.functions.allow_productivity("angels-clay-brick")
angelsmods.functions.allow_productivity("angels-concrete")
angelsmods.functions.allow_productivity("angels-concrete-brick")
angelsmods.functions.allow_productivity("angels-reinforced-concrete-brick")
