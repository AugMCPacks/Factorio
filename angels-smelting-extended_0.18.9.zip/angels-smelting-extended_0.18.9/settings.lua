data:extend(
{
  {
    type = "bool-setting",
    name = "ASE-angels-coil-icons",
    setting_type = "startup",
    default_value = false,
    order = "a",
  },
}
)
