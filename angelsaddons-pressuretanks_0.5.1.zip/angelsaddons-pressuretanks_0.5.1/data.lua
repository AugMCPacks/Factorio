angelsmods = angelsmods or {}
angelsmods.addons = angelsmods.addons or {}
angelsmods.addons.pressuretanks = angelsmods.addons.pressuretanks or {}

require("prototypes.buildings.pressure-tanks")
require("prototypes.recipes.pressure-tanks")
require("prototypes.technology.pressure-tanks-technology")
