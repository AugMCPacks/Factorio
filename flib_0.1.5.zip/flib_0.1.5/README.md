# Factorio Library
The Factorio Library is a set of high-quality, commonly-used utilities for creating Factorio mods. It is meant to be a general library used by all mods to improve compatibility, and eliminate the need for every modder to have their own lib.

[DOCUMENTATION](https://factoriolib.github.io/flib/index.html)