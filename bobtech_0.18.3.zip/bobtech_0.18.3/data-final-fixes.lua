--This file exists because AAII is annoying.

if settings.startup["bobmods-burnerphase"].value == true then
  data.raw["lab"]["burner-lab"].inputs = {"steam-science-pack", "automation-science-pack"}
end

