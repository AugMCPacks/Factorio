data:extend(
{
   {
    type = "bool-setting",
    name = "angels-enable-icon-scaling-silos",
    setting_type = "startup",
    default_value = false,
    order = "a",
   },
}
)


