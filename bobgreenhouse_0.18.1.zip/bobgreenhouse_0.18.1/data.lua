if not bobmods then bobmods = {} end
if not bobmods.greenhouse then bobmods.greenhouse = {} end

require("prototypes.category")
require("prototypes.items")
require("prototypes.entities")
require("prototypes.recipes")
require("prototypes.technology")

