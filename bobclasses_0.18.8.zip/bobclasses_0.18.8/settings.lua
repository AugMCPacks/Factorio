data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-classes-god-mode",
    setting_type = "runtime-global",
    default_value = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-classes-editor-mode",
    setting_type = "runtime-global",
    default_value = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-classes-class-select",
    setting_type = "runtime-global",
    default_value = false,
  },
  {
    type = "bool-setting",
    name = "bobmods-classes-class-select-user",
    setting_type = "runtime-global",
    default_value = false,
  },
}
)
