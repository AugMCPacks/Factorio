global.sign_last_built = {}
global.sign_gui = {}
