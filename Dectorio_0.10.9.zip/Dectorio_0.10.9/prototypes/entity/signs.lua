-- entity/signs

if DECT.ENABLED["signs"] then
	-- Pull in the base entity sounds
	local sounds = require("__base__.prototypes.entity.demo-sounds")

	data:extend(
		{
			{
				type = "simple-entity",
				name = "dect-sign-wood",
				icon = "__Dectorio__/graphics/icons/sign-wood.png",
				icon_size = 64,
				icon_mipmaps = 1,
				flags = {"placeable-neutral"},
				render_layer = "object",
				minable = {mining_time = 0.2, result = "dect-sign-wood", count = 1},
				max_health = 40,
				collision_box = {{-0.15, -0.15}, {0.15, 0.15}},
				selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
				drawing_box = {{-0.5, -1.6}, {0.5, 0.5}},
				repair_sound = {filename = "__base__/sound/manual-repair-simple.ogg"},
				mined_sound = {filename = "__Dectorio__/sound/deconstruct-wood.ogg"},
				vehicle_impact_sound = {filename = "__base__/sound/car-wood-impact.ogg", volume = 1.0},
				pictures = {
					{
						filename = "__Dectorio__/graphics/entity/sign-wood/sign-wood.png",
						priority = "extra-high",
						width = 85,
						height = 65,
						shift = {0.8, -0.45},
						hr_version = {
							filename = "__Dectorio__/graphics/entity/sign-wood/hr-sign-wood.png",
							priority = "extra-high",
							width = 170,
							height = 130,
							shift = {0.8, -0.45},
							scale = 0.5
						}
					}
				}
			},
			{
				type = "simple-entity",
				name = "dect-sign-steel",
				icon = "__Dectorio__/graphics/icons/sign-steel.png",
				icon_size = 64,
				icon_mipmaps = 1,
				flags = {"placeable-neutral"},
				render_layer = "object",
				minable = {mining_time = 0.2, result = "dect-sign-steel", count = 1},
				max_health = 65,
				collision_box = {{-0.15, -0.15}, {0.15, 0.15}},
				selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
				drawing_box = {{-0.5, -1.6}, {0.5, 0.5}},
				repair_sound = {filename = "__base__/sound/manual-repair-simple.ogg"},
				mined_sound = {filename = "__base__/sound/deconstruct-bricks.ogg"},
				vehicle_impact_sound = sounds.generic_impact,
				pictures = {
					{
						filename = "__Dectorio__/graphics/entity/sign-steel/sign-steel.png",
						priority = "extra-high",
						width = 85,
						height = 65,
						shift = {0.77, -0.45},
						hr_version = {
							filename = "__Dectorio__/graphics/entity/sign-steel/hr-sign-steel.png",
							priority = "extra-high",
							width = 170,
							height = 130,
							shift = {0.77, -0.43},
							scale = 0.5
						}
					}
				}
			}
		}
	)
end
